var searchData=
[
  ['sfml_5fdefine_5fdiscrete_5fgpu_5fpreference_0',['SFML_DEFINE_DISCRETE_GPU_PREFERENCE',['../GpuPreference_8hpp.html#ab0233c2d867cbd561036ed2440a4fec0',1,'GpuPreference.hpp']]]
];
